print ()
import turtle
import random
 
def still_in_screen(w,t):
    left_edge = - w.window_width() / 2
    right_edge = w.window_width() / 2
    top_edge = w.window_height() / 2
    bottom_edge = - w.window_height() / 2
 
    turtleX = t.xcor()
    turtleY = t.ycor()
 
    stillIn = True
    if turtleX > right_edge or turtleX <left_edge:
        stillIn = False
    if turtleY > top_edge or turtleY < bottom_edge:
        stillIn = False
 
    return stillIn
 
win = turtle.Screen()
win.bgcolor("black")
al = turtle.Turtle()
ap = turtle.Turtle()
ao = turtle.Turtle()
al.shape("turtle")
ap.shape("turtle")
ao.shape("turtle")
al.color("#ff0066")
ap.color("#00ffff")
ao.color("#66ff66")

ao.penup()
ao.goto(0,400)
ao.pendown()
ao.forward(400)
ao.right(90)
ao.forward(800)
ao.right(90)
ao.forward(800)
ao.right(90)
ao.forward(800)
ao.right(90)
ao.forward(400)

while still_in_screen(win, al,): #runs the loop as long as still_in_screen functions returns TRUE
    coin = random.randrange (0,2)
    coin2 = random.randrange (0,2)
    if coin == 0:
        al.left(120)
        al.forward(50)
    if coin2 == 0:
        ap.left(120)
        ap.forward(50)
    else:
        al.right(120)
        al.forward(50)
        ap.right(120)
        ap.forward(50)

    
    
    
win.exitonclick()
